// Text content stored in variables
var aboutUsText = "This is just a regular site";

// Inject text into the page
document.getElementById("dynamic-content").innerHTML = aboutUsText;

// Change the text of the Products link to Interests
document.querySelector('a[href="product.html"]').innerHTML = "Interests";

// Create a new link element for Human Resources
var hrLink = document.createElement("a");
hrLink.innerHTML = "Human Resources";
hrLink.href = "hr.html"; // Adjust the href as needed

// Insert the new link after the About Us link
var aboutUsLink = document.querySelector('a[href="aboutus.html"]');
aboutUsLink.parentNode.insertBefore(hrLink, aboutUsLink.nextSibling);

//fixed-bottom navbar with the copyright
var bottomNavbar = document.createElement("nav");
bottomNavbar.className = "navbar navbar-dark bg-dark fixed-bottom";
bottomNavbar.innerHTML = '<div class="container"> &copy; ' + new Date().getFullYear() + ' Matthew de Kock </div>';

// Appending new navbar
document.body.appendChild(bottomNavbar);

// This function submits the form
function submitForm() {
  // This retirves the data from teh form
  var name = document.getElementById("name").value;
  var contactNumber = document.getElementById("contactNumber").value;
  var email = document.getElementById("email").value;
  var message = document.getElementById("message").value;

  // The user info
  console.log("Name: " + name);
  console.log("Contact Number: " + contactNumber);
  console.log("Email: " + email);
  console.log("Message: " + message);

  // Start a timer to redirect after 3 seconds
  setTimeout(function () {
    window.location.href = "index.html"; // Replace with the actual home page URL
  }, 3000);
}
